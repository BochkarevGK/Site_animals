import img from './spinning-loading.gif';
import './loading.css';

const Loading  = () =>{


  return(
    <div className="loadign_item">
      <img src={img} alt="" />
    </div>
  )

}



export default Loading;