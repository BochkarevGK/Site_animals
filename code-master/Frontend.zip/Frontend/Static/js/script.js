$(document).ready(function(){
    $('.slider__inner').slick({
        slidesToShow: 3,
        // autoplay: true,
        // autoplaySpeed: 5000,
});
});