﻿namespace AnimalShelter.Application.Requests.LuckyAnimals.Queries.GetLuckyAnimals;

public sealed record LuckyAnimalsVm(IList<LuckyAnimalDto> LuckyAnimals);