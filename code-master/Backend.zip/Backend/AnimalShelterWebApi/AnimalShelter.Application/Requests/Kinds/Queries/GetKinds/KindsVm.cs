﻿namespace AnimalShelter.Application.Requests.Kinds.Queries.GetKinds;

public sealed record KindsVm(IList<KindDto> Kinds);